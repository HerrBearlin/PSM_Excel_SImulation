package GameOfLife;

public class Main {

    public static void main(String[] args) {
        // initialize and start the simulation
        LifeSimulationRunner run = new LifeSimulationRunner();
        run.startLife();

    }

}
